

import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';

Future<void> main() async {
WidgetsFlutterBinding.ensureInitialized();
await SystemChrome.setPreferredOrientations([
DeviceOrientation.portraitUp,
]);
runApp(const RitmoNoPontoApp());
}

class RitmoNoPontoApp extends StatelessWidget {
const RitmoNoPontoApp({super.key});

@override
Widget build(BuildContext context) {
return MaterialApp(
title: 'Ritmo no Ponto',
debugShowCheckedModeBanner: false,
theme: ThemeData(
colorScheme: ColorScheme.fromSeed(
seedColor: const Color(0xFF16A34A),
brightness: Brightness.dark,
),
scaffoldBackgroundColor: const Color(0xFF101411),
useMaterial3: true,
),
home: const PlayerScreen(),
);
}
}

class PlayerScreen extends StatefulWidget {
const PlayerScreen({super.key});

@override
State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen>
with WidgetsBindingObserver {
final AudioPlayer _player = AudioPlayer();

CameraController? _camera;
FaceDetector? _detector;
bool _cameraReady = false;
bool _processingFrame = false;
bool _faceDetected = false;
bool _isFading = false;
bool _rightEyeWasOpen = false;
bool _gestureEnabled = true;

Timer? _fadeTimer;

final List<String> _tracks = [];
int _currentTrack = 0;

// Limiares ajustáveis. Os valores de ML Kit vão de 0 a 1.
static const double _eyeOpenThreshold = 0.75;
static const double _eyeClosedThreshold = 0.25;

String get _currentName => _tracks.isEmpty
? 'Nenhuma faixa selecionada'
: _tracks[_currentTrack].split(Platform.pathSeparator).last;

@override
void initState() {
super.initState();
WidgetsBinding.instance.addObserver(this);
_detector = FaceDetector(
options: FaceDetectorOptions(
enableClassification: true,
performanceMode: FaceDetectorMode.fast,
enableLandmarks: false,
enableContours: false,
minFaceSize: 0.20,
),
);
_startCamera();
}

Future<void> _startCamera() async {
try {
final permission = await Permission.camera.request();
if (!permission.isGranted) return;

final cameras = await availableCameras();  
  final front = cameras.where(  
    (c) => c.lensDirection == CameraLensDirection.front,  
  );  

  if (front.isEmpty) {  
    _showMessage('Câmera frontal não encontrada.');  
    return;  
  }  

  // NV21 no Android e BGRA no iOS.  
  // Este exemplo é direcionado principalmente ao Android.  
  _camera = CameraController(  
    front.first,  
    ResolutionPreset.low,  
    enableAudio: false,  
    imageFormatGroup: Platform.isAndroid  
        ? ImageFormatGroup.nv21  
        : ImageFormatGroup.bgra8888,  
  );  

  await _camera!.initialize();  
  await _camera!.lockCaptureOrientation(  
    DeviceOrientation.portraitUp,  
  );  
  await _camera!.startImageStream(_processFrame);  

  if (mounted) setState(() => _cameraReady = true);  
} catch (e) {  
  _showMessage('Não foi possível iniciar a câmera: $e');  
}

}

InputImage? _toInputImage(CameraImage image) {
final camera = _camera;
if (camera == null || image.planes.isEmpty) return null;

final format = Platform.isAndroid  
    ? InputImageFormat.nv21  
    : InputImageFormat.bgra8888;  

final rotation = InputImageRotationValue.fromRawValue(  
  camera.description.sensorOrientation,  
);  

if (rotation == null) return null;  

// Com NV21 no Android, espera-se um único plano.  
// Se o aparelho fornecer outro formato, não processamos o frame.  
if (Platform.isAndroid &&  
    image.format.group != ImageFormatGroup.nv21) {  
  return null;  
}  

final plane = image.planes.first;  

return InputImage.fromBytes(  
  bytes: plane.bytes,  
  metadata: InputImageMetadata(  
    size: Size(  
      image.width.toDouble(),  
      image.height.toDouble(),  
    ),  
    rotation: rotation,  
    format: format,  
    bytesPerRow: plane.bytesPerRow,  
  ),  
);

}

Future<void> _processFrame(CameraImage image) async {
// Nunca acumular frames: processa um por vez.
if (_processingFrame || _isFading || !_gestureEnabled) return;
_processingFrame = true;

try {  
  final input = _toInputImage(image);  
  if (input == null) return;  

  final faces = await _detector!.processImage(input);  

  if (faces.isEmpty) {  
    _rightEyeWasOpen = false;  
    if (mounted && _faceDetected) {  
      setState(() => _faceDetected = false);  
    }  
    return;  
  }  

  final face = faces.first;  
  final right = face.rightEyeOpenProbability;  
  final left = face.leftEyeOpenProbability;  

  if (mounted && !_faceDetected) {  
    setState(() => _faceDetected = true);  
  }  

  if (right == null || left == null) return;  

  // Rearmar somente quando os dois olhos estiverem abertos.  
  if (right > _eyeOpenThreshold &&  
      left > _eyeOpenThreshold) {  
    _rightEyeWasOpen = true;  
    return;  
  }  

  // Piscada intencional: olho direito fecha e o esquerdo  
  // permanece aberto. Não dispara com ambos fechados.  
  final rightOnlyBlink =  
      _rightEyeWasOpen &&  
      right < _eyeClosedThreshold &&  
      left > _eyeOpenThreshold;  

  if (rightOnlyBlink) {  
    _rightEyeWasOpen = false;  
    await _fadeOutAndPause();  
  }  
} catch (_) {  
  // Erros isolados de um frame não devem derrubar o player.  
} finally {  
  _processingFrame = false;  
}

}

Future<void> _fadeOutAndPause() async {
if (_isFading || !_player.playing) return;

_isFading = true;  
_fadeTimer?.cancel();  

final watch = Stopwatch()..start();  

// Atualiza o volume a cada 20 ms durante 2 segundos.  
_fadeTimer = Timer.periodic(  
  const Duration(milliseconds: 20),  
  (timer) async {  
    final elapsed = watch.elapsedMilliseconds;  
    final fraction = (elapsed / 2000.0).clamp(0.0, 1.0);  

    // Curva linear: volume de 1.0 até 0.0.  
    await _player.setVolume(  
      math.max(0.0, 1.0 - fraction),  
    );  

    if (elapsed >= 2000) {  
      timer.cancel();  
      watch.stop();  

      await _player.pause();  
      await _player.setVolume(1.0);  

      if (mounted) {  
        setState(() => _isFading = false);  
      } else {  
        _isFading = false;  
      }  
    }  
  },  
);

}

Future<void> _pickMp3() async {
try {
final result = await FilePicker.platform.pickFiles(
type: FileType.custom,
allowedExtensions: ['mp3'],
allowMultiple: true,
);

if (result == null) return;  

  final paths = result.files  
      .map((f) => f.path)  
      .whereType<String>()  
      .where((p) => File(p).existsSync())  
      .toList();  

  if (paths.isEmpty) {  
    _showMessage('Nenhum arquivo MP3 acessível foi selecionado.');  
    return;  
  }  

  await _player.stop();  
  setState(() {  
    _tracks  
      ..clear()  
      ..addAll(paths);  
    _currentTrack = 0;  
  });  

  await _loadCurrentTrack();  
} catch (e) {  
  _showMessage('Erro ao carregar MP3: $e');  
}

}

Future<void> _loadCurrentTrack() async {
if (_tracks.isEmpty) return;

try {  
  await _player.setVolume(1.0);  
  await _player.setFilePath(_tracks[_currentTrack]);  
} catch (e) {  
  _showMessage('Não foi possível abrir a faixa: $e');  
}

}

Future<void> _play() async {
if (_tracks.isEmpty) {
await _pickMp3();
return;
}
await _player.setVolume(1.0);
await _player.play();
}

Future<void> _pause() async {
_fadeTimer?.cancel();
await _player.pause();
await _player.setVolume(1.0);
if (mounted) setState(() => _isFading = false);
}

Future<void> _stop() async {
_fadeTimer?.cancel();
await _player.stop();
await _player.setVolume(1.0);
if (mounted) setState(() => _isFading = false);
}

Future<void> _changeTrack(int delta) async {
if (_tracks.isEmpty) return;

await _player.stop();  
_fadeTimer?.cancel();  

setState(() {  
  _currentTrack =  
      (_currentTrack + delta + _tracks.length) % _tracks.length;  
  _isFading = false;  
});  

await _loadCurrentTrack();  
await _player.play();

}

void _showMessage(String message) {
if (!mounted) return;
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(content: Text(message)),
);
}


@override
void didChangeAppLifecycleState(AppLifecycleState state) {
  if (state != AppLifecycleState.resumed) {
    _camera?.stopImageStream().catchError((_) {});
    _rightEyeWasOpen = false;
  }
}


@override
void dispose() {
WidgetsBinding.instance.removeObserver(this);
_fadeTimer?.cancel();
_camera?.dispose();
_detector?.close();
_player.dispose();
super.dispose();
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
title: const Text('Ritmo no Ponto'),
actions: [
Padding(
padding: const EdgeInsets.only(right: 16),
child: Row(
children: [
Icon(
Icons.circle,
size: 12,
color: _faceDetected ? Colors.greenAccent : Colors.grey,
),
const SizedBox(width: 6),
Text(_faceDetected ? 'Face detectada' : 'Câmera'),
],
),
),
],
),
body: SafeArea(
child: Padding(
padding: const EdgeInsets.all(18),
child: Column(
crossAxisAlignment: CrossAxisAlignment.stretch,
children: [
Card(
child: Padding(
padding: const EdgeInsets.all(18),
child: Column(
children: [
const Icon(Icons.music_note, size: 48),
const SizedBox(height: 12),
Text(
_currentName,
textAlign: TextAlign.center,
maxLines: 2,
overflow: TextOverflow.ellipsis,
style: Theme.of(context).textTheme.titleMedium,
),
const SizedBox(height: 12),
StreamBuilder<Duration?>(
stream: _player.durationStream,
builder: (context, durationSnapshot) {
final duration =
durationSnapshot.data ?? Duration.zero;
return StreamBuilder<Duration>(
stream: _player.positionStream,
builder: (context, positionSnapshot) {
final position =
positionSnapshot.data ?? Duration.zero;
final maxMs = duration.inMilliseconds;
final posMs = position.inMilliseconds
.clamp(0, math.max(1, maxMs));
return Column(
children: [
Slider(
value: maxMs == 0
? 0
: posMs.toDouble(),
max: math.max(1, maxMs).toDouble(),
onChanged: maxMs == 0
? null
: (v) => _player.seek(
Duration(
milliseconds: v.round(),
),
),
),
Text(
'${_time(position)} / ${_time(duration)}',
),
],
);
},
);
},
),
if (_isFading)
const Text(
'Parando suavemente…',
style: TextStyle(color: Colors.greenAccent),
),
],
),
),
),
const SizedBox(height: 14),
Wrap(
alignment: WrapAlignment.center,
spacing: 8,
children: [
IconButton.filledTonal(
tooltip: 'Faixa anterior',
onPressed: () => _changeTrack(-1),
icon: const Icon(Icons.skip_previous),
),
IconButton.filled(
tooltip: 'Play',
onPressed: _play,
icon: const Icon(Icons.play_arrow),
),
IconButton.filledTonal(
tooltip: 'Pause',
onPressed: _pause,
icon: const Icon(Icons.pause),
),
IconButton.filledTonal(
tooltip: 'Stop',
onPressed: _stop,
icon: const Icon(Icons.stop),
),
IconButton.filledTonal(
tooltip: 'Próxima faixa',
onPressed: () => _changeTrack(1),
icon: const Icon(Icons.skip_next),
),
],
),
const SizedBox(height: 8),
FilledButton.icon(
onPressed: _pickMp3,
icon: const Icon(Icons.library_music),
label: const Text('Selecionar MP3 do celular'),
),
const SizedBox(height: 12),
const Text(
'Comando facial: pisque somente o olho direito, '
'mantendo o esquerdo aberto. O áudio diminui durante '
'2 segundos e pausa ao terminar.',
textAlign: TextAlign.center,
),
const SizedBox(height: 12),
Expanded(
child: _tracks.isEmpty
? const Center(
child: Text('Sua playlist aparecerá aqui.'),
)
: ListView.builder(
itemCount: _tracks.length,
itemBuilder: (context, index) {
final name = _tracks[index]
.split(Platform.pathSeparator)
.last;
return ListTile(
selected: index == _currentTrack,
leading: Icon(
index == _currentTrack
? Icons.equalizer
: Icons.audiotrack,
),
title: Text(
name,
maxLines: 1,
overflow: TextOverflow.ellipsis,
),
onTap: () async {
await _player.stop();
setState(() => _currentTrack = index);
await _loadCurrentTrack();
await _player.play();
},
);
},
),
),
],
),
),
),
);
}

String _time(Duration d) {
final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
return '$minutes:$seconds';
}
}
